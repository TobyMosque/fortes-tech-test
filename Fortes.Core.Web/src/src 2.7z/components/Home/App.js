﻿export default {
  name: 'home',
  data () {
    return {

    }
  },
  created() {
	  var token = this.$http.headers.common['token'];
	  if (token) {
		  this.$router.push('/recurso');
	  } else {
		  this.$router.push('/login');
	  }
  }
}
