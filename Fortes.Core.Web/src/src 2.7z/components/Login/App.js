﻿export default {
  name: 'login',
  data () {
    return {
    }
  },
  created () {

  }
}
