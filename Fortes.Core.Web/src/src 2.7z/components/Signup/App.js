﻿export default {
  name: 'hello',
  data () {
    return {
    }
  },
  // Send a request to /api/hello
  created () {
  }
}
