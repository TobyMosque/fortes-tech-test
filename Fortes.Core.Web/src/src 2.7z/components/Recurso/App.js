﻿export default {
  name: 'recurso',
  data () {
    return {
    }
  },
  created () {
	  this.$http.get("api/Recurso")
		  .then((res) => {
			  console.log(res.body);
		  })
  }
}
