﻿<template>

</template>

<script src="./App.js">

</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped src="./App.css">

</style>
