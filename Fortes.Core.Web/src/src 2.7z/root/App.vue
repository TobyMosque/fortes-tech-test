﻿<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>

<script src="./App.js">

</script>

<style src="./App.css">

</style>
