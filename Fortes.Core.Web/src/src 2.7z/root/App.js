﻿import Vue from 'vue'
import router from '@/router'

export default {
	name: 'app',
	created() {
		var self = this;
		Vue.http.headers.common['token'] = localStorage.getItem('token');
		Vue.http.interceptors.push(function (request, next) {
			console.log(request);
			next(function (response) {
				console.log(self, response);
				if (response.status === 401) {
					router.push('/login')
				}
			});
		});
		console.log(Vue.http.interceptors.interceptors);
	}
}